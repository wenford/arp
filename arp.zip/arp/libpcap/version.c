char pcap_version[] = "0.9.8";
